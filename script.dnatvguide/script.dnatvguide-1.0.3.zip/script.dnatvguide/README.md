script.dnatvguide
===================

dnaTV is based on FTVGuide which allows you to combine some of your favourite live TV plugins for use with a fully working EPG.

Based on the original TV Guide by twinther.

This repository is maintained by dna.
